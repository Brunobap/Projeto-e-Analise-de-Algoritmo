/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package grafos;

/**
 * Indica o tipo de representacao a ser instanciado em memoria.
 * @author humberto e douglas
 */
public enum TipoDeRepresentacao {
    MATRIZ_DE_ADJACENCIA, 
    MATRIZ_DE_INCIDENCIA, 
    LISTA_DE_ADJACENCIA;
}
